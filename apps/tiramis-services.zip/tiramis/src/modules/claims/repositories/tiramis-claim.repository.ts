import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { DeepPartial, Repository } from 'typeorm';

import { TiramisClaimAssessmentEntity } from '../entities/tiramis-claim-assessment.entity';
import { TiramisClaimIntimationEntity } from '../entities/tiramis-claim-intimation.entity';
import { TiramisClaimNotificationEntity } from '../entities/tiramis-claim-notification.entity';
import { TiramisClaimPaymentEntity } from '../entities/tiramis-claim-payment.entity';
import { TiramisClaimRejectionEntity } from '../entities/tiramis-claim-rejection.entity';
import { TiramisDischargeVoucherEntity } from '../entities/tiramis-discharge-voucher.entity';

@Injectable()
export class TiramisClaimRepository {
  constructor(
    @InjectRepository(TiramisClaimNotificationEntity)
    private readonly notificationRepository: Repository<TiramisClaimNotificationEntity>,
    @InjectRepository(TiramisClaimIntimationEntity)
    private readonly intimationRepository: Repository<TiramisClaimIntimationEntity>,
    @InjectRepository(TiramisClaimAssessmentEntity)
    private readonly assessmentRepository: Repository<TiramisClaimAssessmentEntity>,
    @InjectRepository(TiramisDischargeVoucherEntity)
    private readonly dischargeVoucherRepository: Repository<TiramisDischargeVoucherEntity>,
    @InjectRepository(TiramisClaimPaymentEntity)
    private readonly paymentRepository: Repository<TiramisClaimPaymentEntity>,
    @InjectRepository(TiramisClaimRejectionEntity)
    private readonly rejectionRepository: Repository<TiramisClaimRejectionEntity>,
  ) {}

  createNotification(data: DeepPartial<TiramisClaimNotificationEntity>) {
    return this.notificationRepository.create(data);
  }

  saveNotification(entity: TiramisClaimNotificationEntity) {
    return this.notificationRepository.save(entity);
  }

  createIntimation(data: DeepPartial<TiramisClaimIntimationEntity>) {
    return this.intimationRepository.create(data);
  }

  saveIntimation(entity: TiramisClaimIntimationEntity) {
    return this.intimationRepository.save(entity);
  }

  createAssessment(data: DeepPartial<TiramisClaimAssessmentEntity>) {
    return this.assessmentRepository.create(data);
  }

  saveAssessment(entity: TiramisClaimAssessmentEntity) {
    return this.assessmentRepository.save(entity);
  }

  createDischargeVoucher(data: DeepPartial<TiramisDischargeVoucherEntity>) {
    return this.dischargeVoucherRepository.create(data);
  }

  saveDischargeVoucher(entity: TiramisDischargeVoucherEntity) {
    return this.dischargeVoucherRepository.save(entity);
  }

  createPayment(data: DeepPartial<TiramisClaimPaymentEntity>) {
    return this.paymentRepository.create(data);
  }

  savePayment(entity: TiramisClaimPaymentEntity) {
    return this.paymentRepository.save(entity);
  }

  createRejection(data: DeepPartial<TiramisClaimRejectionEntity>) {
    return this.rejectionRepository.create(data);
  }

  saveRejection(entity: TiramisClaimRejectionEntity) {
    return this.rejectionRepository.save(entity);
  }

  findNotificationByRequestId(requestId: string) {
    return this.notificationRepository.findOne({ where: { requestId } });
  }

  findNotificationById(id: string) {
    return this.notificationRepository.findOne({ where: { id } });
  }

  findAllNotifications() {
    return this.notificationRepository.find({
      order: {
        createdAt: 'DESC',
      },
    });
  }

  findIntimationByRequestId(requestId: string) {
    return this.intimationRepository.findOne({
      where: { requestId },
      relations: { claimants: true },
    });
  }

  findIntimationById(id: string) {
    return this.intimationRepository.findOne({
      where: { id },
      relations: { claimants: true },
    });
  }

  findAllIntimations() {
    return this.intimationRepository.find({
      relations: { claimants: true },
      order: {
        createdAt: 'DESC',
      },
    });
  }

  findAssessmentByRequestId(requestId: string) {
    return this.assessmentRepository.findOne({
      where: { requestId },
      relations: { claimants: true },
    });
  }

  findAssessmentById(id: string) {
    return this.assessmentRepository.findOne({
      where: { id },
      relations: { claimants: true },
    });
  }

  findAllAssessments() {
    return this.assessmentRepository.find({
      relations: { claimants: true },
      order: {
        createdAt: 'DESC',
      },
    });
  }

  findDischargeVoucherByRequestId(requestId: string) {
    return this.dischargeVoucherRepository.findOne({
      where: { requestId },
      relations: { claimants: true },
    });
  }

  findDischargeVoucherById(id: string) {
    return this.dischargeVoucherRepository.findOne({
      where: { id },
      relations: { claimants: true },
    });
  }

  findAllDischargeVouchers() {
    return this.dischargeVoucherRepository.find({
      relations: { claimants: true },
      order: {
        createdAt: 'DESC',
      },
    });
  }

  findPaymentByRequestId(requestId: string) {
    return this.paymentRepository.findOne({
      where: { requestId },
      relations: { claimants: true },
    });
  }

  findPaymentById(id: string) {
    return this.paymentRepository.findOne({
      where: { id },
      relations: { claimants: true },
    });
  }

  findAllPayments() {
    return this.paymentRepository.find({
      relations: { claimants: true },
      order: {
        createdAt: 'DESC',
      },
    });
  }

  findRejectionByRequestId(requestId: string) {
    return this.rejectionRepository.findOne({
      where: { requestId },
      relations: { claimants: true },
    });
  }

  findRejectionById(id: string) {
    return this.rejectionRepository.findOne({
      where: { id },
      relations: { claimants: true },
    });
  }

  findAllRejections() {
    return this.rejectionRepository.find({
      relations: { claimants: true },
      order: {
        createdAt: 'DESC',
      },
    });
  }
}
