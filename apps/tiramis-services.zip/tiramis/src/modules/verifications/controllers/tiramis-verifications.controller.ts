import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { ApiBody, ApiConsumes, ApiOperation, ApiTags } from '@nestjs/swagger';

import {
  CompanyVerificationDto,
  CoverNoteVerificationDto,
  DetailsVerificationDto,
  MotorVerificationDto,
  NinVerificationDto,
} from '../dto/create-verification.dto';
import { TiramisVerificationService } from '../services/tiramis-verification.service';

@ApiTags('Tiramis Verifications')
@ApiConsumes('application/json')
@Controller('tiramis/verifications')
export class TiramisVerificationsController {
  constructor(
    private readonly tiramisVerificationService: TiramisVerificationService,
  ) {}

  @ApiOperation({ summary: 'Verify a cover note reference' })
  @ApiBody({ type: CoverNoteVerificationDto })
  @Post('cover-note')
  verifyCoverNote(@Body() dto: CoverNoteVerificationDto) {
    return this.tiramisVerificationService.verifyCoverNote(dto);
  }

  @ApiOperation({ summary: 'Verify a NIN' })
  @ApiBody({ type: NinVerificationDto })
  @Post('nin')
  verifyNin(@Body() dto: NinVerificationDto) {
    return this.tiramisVerificationService.verifyNin(dto);
  }

  @ApiOperation({ summary: 'Verify a company registration' })
  @ApiBody({ type: CompanyVerificationDto })
  @Post('company')
  verifyCompany(@Body() dto: CompanyVerificationDto) {
    return this.tiramisVerificationService.verifyCompany(dto);
  }

  @ApiOperation({ summary: 'Verify motor registration or chassis details' })
  @ApiBody({ type: MotorVerificationDto })
  @Post('motor')
  verifyMotor(@Body() dto: MotorVerificationDto) {
    return this.tiramisVerificationService.verifyMotor(dto);
  }

  @ApiOperation({ summary: 'Verify combined motor and cover note details' })
  @ApiBody({ type: DetailsVerificationDto })
  @Post('details')
  verifyDetails(@Body() dto: DetailsVerificationDto) {
    return this.tiramisVerificationService.verifyDetails(dto);
  }

  @Get('request/:requestId')
  findByRequestId(@Param('requestId') requestId: string) {
    return this.tiramisVerificationService.findByRequestId(requestId);
  }
}
